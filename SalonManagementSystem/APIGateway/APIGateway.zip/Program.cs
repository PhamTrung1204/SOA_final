using Ocelot.DependencyInjection;
using Ocelot.Middleware;
using Microsoft.Extensions.Configuration;
using Ocelot.Provider.Consul;
using Microsoft.AspNetCore.Builder;

var builder = WebApplication.CreateBuilder(args);

// Load cấu hình Ocelot
builder.Configuration.AddJsonFile("ocelot.json", optional: false, reloadOnChange: true);

// Cấu hình Kestrel lắng nghe cổng 8080 (trong container)
builder.WebHost.ConfigureKestrel(options =>
{
    options.ListenAnyIP(8080);
});

// Đăng ký Ocelot + Consul
builder.Services.AddOcelot(builder.Configuration)
                .AddConsul();

// Swagger (nếu bạn dùng)
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Middleware
app.UseRouting();

app.UseEndpoints(endpoints =>
{
    endpoints.MapGet("/", () => "API Gateway is running...");
});

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "API Gateway V1");
        c.RoutePrefix = string.Empty;
    });
}

// ❗ Bắt buộc phải là cuối cùng
await app.UseOcelot();

app.Run();
