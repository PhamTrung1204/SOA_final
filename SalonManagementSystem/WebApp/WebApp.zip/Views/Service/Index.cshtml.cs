﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SalonManagementSystem.Shared.Models;
using System.Net.Http.Json;

namespace WebApp.Pages.Service
{
    public class IndexModel : PageModel
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IConfiguration _configuration;

        public IndexModel(IHttpClientFactory httpClientFactory, IConfiguration configuration)
        {
            _httpClientFactory = httpClientFactory;
            _configuration = configuration;
        }

        public List<SalonManagementSystem.Shared.Models.Service> Services { get; set; } = new List<SalonManagementSystem.Shared.Models.Service>();

        public async Task OnGetAsync()
        {
            try
            {
                var apiGatewayUrl = _configuration["ApiGateway"];
                if (string.IsNullOrEmpty(apiGatewayUrl))
                {
                    throw new Exception("API Gateway URL is not configured in appsettings.json");
                }

                var client = _httpClientFactory.CreateClient();
                client.BaseAddress = new Uri(apiGatewayUrl);

                var response = await client.GetAsync("api/services");
                if (response.IsSuccessStatusCode)
                {
                    Services = await response.Content.ReadFromJsonAsync<List<SalonManagementSystem.Shared.Models.Service>>();
                }
                else
                {
                    Services = new List<SalonManagementSystem.Shared.Models.Service>();
                    TempData["Error"] = $"Không thể lấy danh sách dịch vụ. Status: {response.StatusCode}";
                }
            }
            catch (Exception ex)
            {
                Services = new List<SalonManagementSystem.Shared.Models.Service>();
                TempData["Error"] = $"Lỗi: {ex.Message}";
            }
        }
    }
}